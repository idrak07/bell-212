package com.genuinecoder.springserver.domain.enumeration;

public enum QuestionType {
    MOCK, ORIGINAL
}
