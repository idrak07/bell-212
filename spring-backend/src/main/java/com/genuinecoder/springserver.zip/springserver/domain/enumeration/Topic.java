package com.genuinecoder.springserver.domain.enumeration;

public enum Topic {
    ENGINE, AIR_FRAME, ELECTRONIC_COMPONENTS, INSTRUMENTS, RADIO
}
